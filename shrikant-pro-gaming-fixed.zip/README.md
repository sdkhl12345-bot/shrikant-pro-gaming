# SHRIKANT PRO GAMING — project review & setup

## Included
- `public/`: customer store, login/register, account/orders, contact page, and a basic Study Center.
- `public/admin.html`: admin product/pricing/discount/coupon/settings dashboard.
- `api/`: serverless checkout, verification, webhook and contact endpoints.
- `supabase/schema.sql`: database schema and row-level security policies.

## Fix applied in this revision
- Fixed frontend route handling: the previous `view(...) || store()` pattern could call the Store page after navigating to other pages. Routes now dispatch to the selected page directly.
- Added a basic Study Center with subject selection, study goal, task checklist, and notes. These study items are saved only in the current browser/device using localStorage; they are not synced to user accounts.
- Added Study Center navigation.

## Important: not production-ready until configured and tested
1. Create a Supabase project and run `supabase/schema.sql` in its SQL editor.
2. Set the Vercel environment variables from `.env.example`. Never expose `SUPABASE_SERVICE_ROLE_KEY` or PhonePe secrets in frontend code.
3. Create your owner account, then run the admin insert shown at the bottom of `supabase/schema.sql` with your exact account email. Do not share your password.
4. Configure and test PhonePe with sandbox credentials first. The PhonePe endpoints, webhook authentication, and production credentials must be verified against your current PhonePe merchant documentation before accepting real payments. Do not mark a payment as successful manually based on screenshots.
5. Deploy to Vercel and test signup, email confirmation, registration fee, product purchase, payment failure, refund workflow, admin access, and mobile navigation.

## Known limitations
- Study Center data is device-local and can be lost if browser data is cleared; it does not yet sync across accounts/devices.
- Payment gateway functionality cannot be confirmed until valid merchant credentials and a configured PhonePe merchant account are supplied and tested.
- Admin dashboard actions and database security depend on correct Supabase schema/RLS setup and an admin row for the owner.
- The “Mark refunded” admin action only updates the site's records/access; an actual refund must be completed through the payment provider.
- This ZIP is source code, not a deployed website.

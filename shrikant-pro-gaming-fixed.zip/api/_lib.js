import { createClient } from '@supabase/supabase-js';
import crypto from 'node:crypto';
export const db = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
export async function getUser(req) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  if (!t) return null;
  const { data } = await db.auth.getUser(t);
  return data?.user || null;
}
const inWindow = (s, e) => (!s || new Date(s) <= new Date()) && (!e || new Date(e) >= new Date());
const apply = (paise, type, value) =>
  type === 'percent' ? Math.round(paise * (100 - Math.min(value, 100)) / 100) : paise - Math.round(value * 100);
export function productPrice(p) {
  let x = p.price_paise;
  if (p.discount_type && inWindow(p.discount_start, p.discount_end)) x = apply(x, p.discount_type, Number(p.discount_value));
  return Math.max(x, 0);
}
export function couponPrice(paise, c) {
  if (!c || !c.active || !inWindow(c.starts_at, c.ends_at) || (c.max_uses && c.used >= c.max_uses)) return null;
  return Math.max(apply(paise, c.type, Number(c.value)), 0);
}
export const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

// ---- PhonePe Standard Checkout v2. Endpoints/fields ko PhonePe docs aur sandbox se verify karna zaroori hai ----
const prod = process.env.PHONEPE_ENV === 'production';
const PG = prod ? 'https://api.phonepe.com/apis/pg' : 'https://api-preprod.phonepe.com/apis/pg-sandbox';
const IDM = prod ? 'https://api.phonepe.com/apis/identity-manager' : 'https://api-preprod.phonepe.com/apis/pg-sandbox';
async function token() {
  const r = await fetch(`${IDM}/v1/oauth/token`, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: process.env.PHONEPE_CLIENT_ID, client_secret: process.env.PHONEPE_CLIENT_SECRET,
      client_version: process.env.PHONEPE_CLIENT_VERSION || '1', grant_type: 'client_credentials' })
  });
  const j = await r.json(); if (!j.access_token) throw new Error('PhonePe auth failed'); return j.access_token;
}
export async function createPayment(orderId, paise, redirectUrl) {
  const r = await fetch(`${PG}/checkout/v2/pay`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `O-Bearer ${await token()}` },
    body: JSON.stringify({ merchantOrderId: orderId, amount: paise,
      paymentFlow: { type: 'PG_CHECKOUT', message: 'SHRIKANT PRO GAMING', merchantUrls: { redirectUrl } } })
  });
  const j = await r.json(); if (!j.redirectUrl) throw new Error('PhonePe order failed'); return j;
}
export async function orderStatus(orderId) {
  const r = await fetch(`${PG}/checkout/v2/order/${orderId}/status`, { headers: { Authorization: `O-Bearer ${await token()}` } });
  return r.json(); // { state: COMPLETED | FAILED | PENDING, amount, ... }
}
export async function settle(order) {
  const s = await orderStatus(order.id);
  if (s.state === 'COMPLETED' && Number(s.amount) === order.amount_paise) {
    await db.rpc('fulfill_order', { p_id: order.id, p_ref: s.orderId || null }); return 'success';
  }
  if (s.state === 'FAILED') { await db.from('orders').update({ status: 'failed' }).eq('id', order.id).eq('status', 'pending'); return 'failed'; }
  return 'pending';
}

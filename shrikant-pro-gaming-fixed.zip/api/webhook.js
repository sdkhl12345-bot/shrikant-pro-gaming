import { db, sha, settle } from './_lib.js';
export default async function handler(req, res) {
  if (req.headers.authorization !== sha(`${process.env.PHONEPE_WEBHOOK_USER}:${process.env.PHONEPE_WEBHOOK_PASS}`)) return res.status(401).end();
  try {
    const id = req.body?.payload?.merchantOrderId;
    const { data: o } = await db.from('orders').select('*').eq('id', id).maybeSingle();
    if (o && o.status === 'pending') await settle(o); // webhook par akele bharosa nahi: status API se dobara check
    res.status(200).end();
  } catch (e) { console.error(e); res.status(500).end(); }
}

import { db, getUser, settle } from './_lib.js';
export default async function handler(req, res) {
  try {
    const user = await getUser(req); if (!user) return res.status(401).json({ error: 'Pehle login karein' });
    const { data: o } = await db.from('orders').select('*').eq('id', req.query.order).eq('user_id', user.id).maybeSingle();
    if (!o) return res.status(404).json({ error: 'Order nahi mila' });
    res.json({ status: o.status === 'pending' ? await settle(o) : o.status });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Verify nahi ho paya' }); }
}

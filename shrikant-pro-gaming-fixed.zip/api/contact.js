import { db, sha } from './_lib.js';
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { name, email, message, website } = req.body || {};
  if (website) return res.json({ ok: true }); // honeypot: bots ko chup-chaap ok
  const n = String(name || '').trim(), e = String(email || '').trim(), m = String(message || '').trim();
  if (n.length < 2 || n.length > 80 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) || m.length < 10 || m.length > 1500)
    return res.status(400).json({ error: 'Sahi naam, email aur message (10+ akshar) daalein' });
  const ip = sha(String(req.headers['x-forwarded-for'] || '').split(',')[0] + 'spg');
  const since = new Date(Date.now() - 3600e3).toISOString();
  const { count } = await db.from('contact_messages').select('id', { count: 'exact', head: true }).eq('ip_hash', ip).gte('created_at', since);
  if (count >= 3) return res.status(429).json({ error: 'Bahut zyada messages. Baad me try karein.' });
  await db.from('contact_messages').insert({ name: n, email: e, message: m, ip_hash: ip });
  res.json({ ok: true });
}

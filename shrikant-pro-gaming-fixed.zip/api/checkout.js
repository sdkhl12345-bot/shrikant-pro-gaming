import { db, getUser, productPrice, couponPrice, createPayment } from './_lib.js';
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const user = await getUser(req); if (!user) return res.status(401).json({ error: 'Pehle login karein' });
    const { kind, product_id, coupon } = req.body || {};
    const { data: prof } = await db.from('profiles').select('registration_paid').eq('id', user.id).single();
    let paise, row = { user_id: user.id, kind };
    if (kind === 'registration') {
      if (prof.registration_paid) return res.status(400).json({ error: 'Registration ho chuka hai' });
      const { data: s } = await db.from('settings').select('value').eq('key', 'registration_fee_paise').single();
      paise = parseInt(s.value, 10);
    } else if (kind === 'product') {
      if (!prof.registration_paid) return res.status(403).json({ error: 'Pehle registration fee dein' });
      const { data: p } = await db.from('products').select('*').eq('id', product_id).eq('published', true).eq('available', true).maybeSingle();
      if (!p) return res.status(404).json({ error: 'Product available nahi hai' });
      const { data: own } = await db.from('entitlements').select('user_id').eq('user_id', user.id).eq('product_id', p.id).maybeSingle();
      if (own) return res.status(400).json({ error: 'Ye product aap pehle se khareed chuke hain' });
      paise = productPrice(p); row.product_id = p.id;
      if (coupon) {
        const code = String(coupon).trim().toUpperCase().slice(0, 40);
        const { data: c } = await db.from('coupons').select('*').eq('code', code).maybeSingle();
        const np = couponPrice(paise, c); if (np === null) return res.status(400).json({ error: 'Coupon galat ya expire hai' });
        paise = np; row.coupon = code;
      }
    } else return res.status(400).json({ error: 'Invalid request' });
    row.amount_paise = paise;
    const { data: order, error } = await db.from('orders').insert(row).select().single(); if (error) throw error;
    if (paise === 0) { await db.rpc('fulfill_order', { p_id: order.id, p_ref: 'free' }); return res.json({ free: true }); }
    if (paise < 100) return res.status(400).json({ error: 'Minimum amount ₹1 hai' });
    const pay = await createPayment(order.id, paise, `${process.env.SITE_URL}/#/return/${order.id}`);
    res.json({ redirectUrl: pay.redirectUrl });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Payment shuru nahi ho paya. Baad me try karein.' }); }
}

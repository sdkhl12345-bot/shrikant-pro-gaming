create extension if not exists pgcrypto;
create table admins(user_id uuid primary key references auth.users on delete cascade);
create function is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from admins where user_id=auth.uid()) $$;

create table profiles(id uuid primary key references auth.users on delete cascade, full_name text, phone text,
  registration_paid boolean not null default false, created_at timestamptz default now());
create function new_user() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into profiles(id,full_name) values(new.id,new.raw_user_meta_data->>'full_name'); return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function new_user();

create table products(id uuid primary key default gen_random_uuid(), name text not null, description text,
  price_paise int not null check(price_paise>=0), discount_type text check(discount_type in('percent','fixed')),
  discount_value numeric, discount_start timestamptz, discount_end timestamptz,
  published boolean default false, available boolean default true, created_at timestamptz default now());
create table product_delivery(product_id uuid primary key references products on delete cascade, content text not null);
create table coupons(code text primary key, type text check(type in('percent','fixed')), value numeric not null,
  starts_at timestamptz, ends_at timestamptz, active boolean default true, max_uses int, used int default 0);
create table orders(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users,
  kind text not null check(kind in('registration','product')), product_id uuid references products, coupon text,
  amount_paise int not null, status text not null default 'pending' check(status in('pending','success','failed','refunded')),
  gateway_ref text, created_at timestamptz default now(), paid_at timestamptz);
create table entitlements(user_id uuid references auth.users, product_id uuid references products,
  order_id uuid references orders, primary key(user_id,product_id));
create table settings(key text primary key, value text);
insert into settings values('registration_fee_paise','1000'),('support_phone',''),('whatsapp',''),('support_email','');
create table contact_messages(id uuid primary key default gen_random_uuid(), name text, email text, message text,
  ip_hash text, created_at timestamptz default now());

-- Paid hone par sirf ek baar fulfill hota hai (duplicate credit nahi)
create function fulfill_order(p_id uuid, p_ref text) returns boolean language plpgsql security definer set search_path=public as $$
declare o orders;
begin
  update orders set status='success', paid_at=now(), gateway_ref=p_ref where id=p_id and status='pending' returning * into o;
  if not found then return false; end if;
  if o.kind='registration' then update profiles set registration_paid=true where id=o.user_id;
  else insert into entitlements values(o.user_id,o.product_id,o.id) on conflict do nothing; end if;
  if o.coupon is not null then update coupons set used=used+1 where code=o.coupon; end if;
  return true;
end $$;
revoke execute on function fulfill_order from public, anon, authenticated;

alter table admins enable row level security; alter table profiles enable row level security;
alter table products enable row level security; alter table product_delivery enable row level security;
alter table coupons enable row level security; alter table orders enable row level security;
alter table entitlements enable row level security; alter table settings enable row level security;
alter table contact_messages enable row level security;

create policy p_prof_sel on profiles for select using(id=auth.uid() or is_admin());
create policy p_prof_upd on profiles for update using(id=auth.uid()) with check(id=auth.uid());
create policy p_prod_sel on products for select using(published or is_admin());
create policy p_prod_all on products for all using(is_admin()) with check(is_admin());
create policy p_del_sel on product_delivery for select using(is_admin() or exists(select 1 from entitlements e where e.product_id=product_delivery.product_id and e.user_id=auth.uid()));
create policy p_del_all on product_delivery for all using(is_admin()) with check(is_admin());
create policy p_coup on coupons for all using(is_admin()) with check(is_admin());
create policy p_ord_sel on orders for select using(user_id=auth.uid() or is_admin());
create policy p_ord_upd on orders for update using(is_admin());
create policy p_ent_sel on entitlements for select using(user_id=auth.uid() or is_admin());
create policy p_ent_del on entitlements for delete using(is_admin());
create policy p_set_sel on settings for select using(true);
create policy p_set_all on settings for all using(is_admin()) with check(is_admin());
create policy p_msg on contact_messages for select using(is_admin());
create policy p_adm on admins for select using(user_id=auth.uid());
-- Customer registration_paid khud nahi badal sakta:
revoke update on profiles from authenticated; grant update(full_name,phone) on profiles to authenticated;
-- Signup ke baad apne account ko admin banane ke liye (EMAIL badlo):
-- insert into admins select id from auth.users where email='YOUR@EMAIL';
